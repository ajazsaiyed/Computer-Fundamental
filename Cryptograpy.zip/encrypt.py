from cryptography.fernet import Fernet
import base64, hashlib

#taking user input message and key 
message=input("Enter your text : ----- ")
USER_KEY = input("Enter your key : ----------------------")

#encoding user key here
ENCODED_KEY=USER_KEY.encode("ascii")
HASH_KEY = hashlib.md5(ENCODED_KEY).hexdigest()
HASH_KEY=bytes(HASH_KEY,'UTF-8') #converting key into bytes key
BASE_KEY = base64.urlsafe_b64encode(HASH_KEY)#converting key into base 64 key
encode=message.encode()  
f=Fernet(BASE_KEY)
encrypted_message=f.encrypt(encode)
print("This is your Cipher Text")
print()
print(encrypted_message)
#writing aencrypted data in file
file = open('USER_FILE.key', 'wb')  # Open the file as wb to write bytes
file.write(encrypted_message)  # The key is type bytes still
file.close()
