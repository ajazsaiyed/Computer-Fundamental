from cryptography.fernet import Fernet
import base64, hashlib

#opening a data file here
file=open('USER_FILE.key','rb')
FILE_DATA=file.read()#reading a data from the file
file.close#closing a file
print()
print()
print("This is your Cipher Text :   ")
print()
print()
#printing a file data
print(FILE_DATA)
print()
print()
#taking user input
USER_KEY = input("Please enter your secrete key here :--------------")
ENCODED_KEY=USER_KEY.encode("ascii")#encoding user key
HASH_KEY = hashlib.md5(ENCODED_KEY).hexdigest()
HASH_KEY=bytes(HASH_KEY,'UTF-8')#converting it into bytes form
BASE_KEY = base64.urlsafe_b64encode(HASH_KEY)#converting it into base 64
f2=Fernet(BASE_KEY)  
#decrypting file data help of key
Decrypted_DATA=f2.decrypt(FILE_DATA)
PLAIN_TEXT=Decrypted_DATA.decode()
#printing original text
print(PLAIN_TEXT)
