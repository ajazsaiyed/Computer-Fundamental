# importing Libraries
from os import path
import csv


def csv_checker(file):
    """
    csv_checker() takes file as an parameter and checks if csv_file Exists Or not.
    If it is present then it will read csv contents to list and return.
    if it is not present then it will create a new csv file and load sample data to it.

        Parameters:
                file (string):file it is the name of the csv file containing data

        Returns:
                items(List):This returns a list of all items present in Store.
    """
    if path.exists(file):
        with open(file, 'r') as f:
            csv_items = csv.DictReader(f)
            _items = []
            for item in csv_items:
                _items.append(item)
            return _items
    else:

        _items = [{'ID': '0123456789', 'name': "Oreo", 'price': 28.56, 'stock': 50},
                  {'ID': '0000000009', 'name': "Mango Juice", 'price': 10.02, 'stock': 25}]
        save_items(_items)
        return _items


def save_items(_items):
    """
    save_items() takes list of item as input and saves the items data to the csv file.

    Parameters:
            _items(List): It contains all the data to be stored in the csv file.
    """

    with open(csv_file, 'w+') as f:
        field_names = ['ID', 'name', 'price', 'stock']
        item_saver = csv.DictWriter(f, fieldnames=field_names)
        item_saver.writeheader()
        for item in _items:
            item_saver.writerow(item)


def print_items(_items):
    """
    print_items() takes list of items as input and prints all the items present in the list

    Parameters:
            _items(List): It contains all the data to be stored in the csv file.

    """
    print("ID", " " * 9, "Name", " " * 14, "Price", " " * 3, "Stock")
    print("-"*48)
    for item in _items:
        print(item['ID'], " " * (9-len(item['ID'])), item['name'], " " * (20-len(item['name'])), item['price'], " " * (7-len(item['price'])), item['stock'])
    print("-"*48)


def search_id(_items, _id):
    """
    search_id() takes List of items,id of item as input and search for the matching item with same item id.

        Parameters:
                _items(List): It contains all the data to be stored in the csv file.
                _id(string): id to search product in the list

    """
    item = _items[id_validator(_items, id_padder(_id), "fetch")]
    if item != None:
        print("ID", " " * 9, "Name", " " * 14, "Price", " " * 3, "Stock")
        print("-"*48)
        print(item['ID'], " " * (9-len(item['ID'])), item['name'], " " * (20-len(item['name'])), item['price'], " " * (7-len(item['price'])), item['stock'])
        print("-"*48)
    else:
        print("No product Exists")


def search_name(_items, _name):
    """
    search_name() takes List of items,name of item as input and search for the matching item with same item name.

        Parameters:
                _items(List): It contains all the data to be stored in the csv file.
                _name(string): name to search item in the list

    """
    for item in _items:
        if item['name'] == _name:
            print("ID", " " * 9, "Name", " " * 14, "Price", " " * 3, "Stock")
            print("-"*48)
            print(item['ID'], " " * (9-len(item['ID'])), item['name'], " " * (9-len(item['name'])), item['price'], " " * (7-len(item['price'])), item['stock'])
            print("-"*48)


def delete_id(_items, _id):
    """
    delete_id() takes List of items,id of item as input and search for the matching item with same item id And
    deletes that item.

        Parameters:
                _items(List): It contains all the data to be stored in the csv file.
                _id(string): id to delete item in the list

    """
    index = id_validator(_items, id_padder(_id), "fetch")
    if index != None:
        _items.pop(index)
        save_items(_items)
    else:
        print("No product Exists")


def add_new_item(_items, _new_item):
    """
    add_new_item() takes List of items,and a dictionary Containing New Item and adds to the csv file.

        Parameters:
                _items(List): It contains all the data to be stored in the csv file.
                _new_item(Dict): dictionary containing info for new item.

    """

    _items.append(_new_item)
    save_items(_items)


def update_id(_items, _id):
    """
    update_id() takes List of items,id of item as input and search for the matching item with same item id,
    Then It prints a menu for user to update different contents of item like its name,price,stock etc.

        Parameters:
                _items(List): It contains all the data to be stored in the csv file.
                _id(string): id to search item in the list

    """
    item = _items[id_validator(_items, id_padder(_id), "fetch")]

    while True:
        print(" " * 7 + " Update Menu " + " " * 7)
        print("  1.Update Name \t2.Update price")
        print("  3.Update stock  \t4.Exit")
        _choice = -1
        while _choice > 4 or _choice < 0:
            _choice = int(input("INPUT:"))
        if _choice == 1:
            _name = input("Name?\t")
            while len(_name) < 1 and len(_name) > 21:
                _name = input("Name?\t")
            item['name'] = _name.title()
            save_items(_items)

        elif _choice == 2:
            try:
                _price = float(input("Price?\t"))
                item['price'] = "{:.2f}".format(_price)

                save_items(_items)
            except:
                print("Enter value in integer Or Float form")
                pass

        elif _choice == 3:
            try:
                _stock = int(input("Stock?\t"))
                item['stock'] = _stock
                save_items(_items)
            except:
                print("Enter value in integer form")
                pass
        elif _choice == 4:
            print("Aborting Updation")
            break


def help_menu():
    """
    help_menu() displays the help for user if he/she is having any problem to use the program.
    """
    print("1.List ALL=> List ALL is used display all the items present in the store in tabular form.")
    print(
        "2.Search ID=> Search ID search for the matching item with same item id inputted by user and display the item "
        "information")
    print(
        "3.Search Name=> Search Name search for the matching item with same item name inputted by user and display "
        "the item information")
    print("4.Delete ID=> Delete ID option is used to delete an item from list and store by using its item_id")
    print('''5.Update ID=> Update ID is used to update the item information like name,price,stock easily.''')
    print(
        '''6.ADD ID=>Add ID is used to add a new item in the store by taking required information of item from the 
        user.''')
    print("7.Exit=> It exits the Program.  ")
    print("8.Help=> Help Shows the user help menu on the screen.")


def id_padder(_id):
    """
    id_padder() takes id as input and returns by filling the string from left side
    until it reaches length of 10.

        Parameters:
                _id (string):Item id to be padded.

        Returns:
                _id.zfill(10):Returning padded _id string after padding.
    """
    return _id.zfill(10)


# validation Functions

def id_validator(_items, _id, option):
    """
   id_validator() takes List of items,,item id ,option as input it checks if item is present in list if it is present
   in list then it returns value according to option specified.

        Parameters:
                option:
                _items(List): It contains all the data stored in the csv file.
                _id(string): id to search item in the list.
        Returns:
                True(Boolean):If item is present in list and option specified is Validate
                item.index(int):If item is present in list and option specified is fetch then it returns index of item.

    """
    for item in _items:
        if item['ID'] == _id:
            if option == "validate":
                return True
            elif option == "fetch":
                return items.index(item)


# csv file to store data
csv_file = "items_data.csv"
# retereiving data in form of list from csv
items = csv_checker(csv_file)
# printing user menu until user exits
while True:
    user_choice = -1
    # printing user menu
    print("-" * 30)
    print("-" * 3 + " WELCOME TO DATA MANAGER " + "-" * 3)
    print("-" * 6 + " " * 6 + " Menu " + " " * 6 + "-" * 6)
    print("  1.List ALL     \t2.Search ID")
    print("  3.Search Name  \t4.Delete ID")
    print("  5.Update ID    \t6.Add ID")
    print("  7.Exit         \t8.Help")
    print("-" * 30)
    # validating user choice
    while user_choice > 8 or user_choice < 0:
        user_choice = int(input("INPUT:"))
    if user_choice == 1:
        # listing all the items in csv
        print_items(items)
    elif user_choice == 2:
        # searching item by id
        _id = input("ID?\t")
        search_id(items, _id)
    elif user_choice == 3:
        # searching item by name
        _name = input("Name?\t")
        while 0 > len(_name) > 21:
            _name = input("Name?\t")
        search_name(items, _name.title())
    elif user_choice == 4:
        # deleting item by id
        _id = input("ID?\t")
        delete_id(items, _id)
    elif user_choice == 5:
        # update item
        _id = id_padder(input("ID?\t"))
        if id_validator(items, _id, "validate"):
            update_id(items, _id)
        else:
            print("No Item Exists")
    elif user_choice == 6:
        # adding new item
        _id = id_padder(input("ID?\t"))
        #validating id
        while id_validator(items, _id, "validate"):
            print("ERROR ID EXISTS.")
            _id = id_padder(input("Id?\t"))
        _name = input("Name?\t")
        #validating name
        while 0 > len(_name) > 21:
            _name = input("Name?\t")
        try:
            _price = float(input("Price?\t"))
        except:
            print("Enter value in integer Or Float form")
            continue
        try:
            _stock = int(input("Stock?\t"))
        except:
            print("Enter value in integer form")
            continue
        new_item = {'ID': _id, 'name': _name.title(), 'price': "{:.2f}".format(_price), 'stock': _stock}
        add_new_item(items, new_item)
    elif user_choice == 7:
        # exiting
        print("BYE")
        break
    elif user_choice == 8:
        # help menu
        help_menu()
