import matplotlib.pyplot as plt
import numpy as np
from numpy import cos as cos
from numpy import sin as sin

R = 10  # radius of the circle
r = 3  # Radius of the smaller circle
o = 7  # offset in moving circle

resolution = 1000
i = 32  # iteration it is used to how many time to you want to rotate the main circle
t = np.linspace(0, i*2*np.pi, resolution)
x = (R+r)*cos(t) - (r+o) * cos(((R+r)/r)*t)
y = (R+r)*sin(t) - (r+o) * sin(((R+r)/r)*t)
plt.figure(figsize=(4,4))
plt.plot(x, y)
plt.show()




